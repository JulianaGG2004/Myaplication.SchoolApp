package com.electiva.schoolapp.model

data class CalificacionesModel(
    var id: String? = null,
    var nomEstu: String? = null,
    var curso: String? = null,
    var materia: String? = null,
    var valorCali: String? = null,
    var nomActi: String? = null,


)